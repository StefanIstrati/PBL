import json
from classes import Teacher, Course, Group, Offices

def load_data_from_json(file_path):
    teachers = []
    courses = []
    groups = []
    offices = []

    with open(file_path, 'r') as file:
        data = json.load(file)
        for entry in data:
            if entry['type'] == 'Teacher':
                teacher_data = entry['data']
                courses_data = [(course[0], course[1]) for course in teacher_data['courses']]
                teachers.append(Teacher(teacher_data['name'], courses_data))
            elif entry['type'] == 'Course':
                course_data = entry['data']
                courses.append(Course(course_data['name'], course_data['course_type']))
            elif entry['type'] == 'Group':
                group_data = entry['data']
                group_courses = []
                for course in group_data['courses']:
                    if len(course) == 3:
                        group_courses.append((course[0], course[1], course[2]))
                    else:
                        print("Invalid data for group:", group_data['name'])
                groups.append(Group(group_data['name'], group_courses))
            elif entry['type'] == 'Office':
                office_data = entry['data']
                offices.append(Offices(office_data['name'], office_data['office_type']))

    return teachers, courses, groups, offices

def create_list_of_tuples(teachers, courses, groups, offices):
    result = []

    for group in groups:
        for group_course in group.courses:
            for course in courses:
                if (group_course[0] == course.name and group_course[1] == course.course_type):
                    for teacher in teachers:
                        for teacher_course in teacher.courses:
                            if (teacher_course[0] == course.name and teacher_course[1] == course.course_type):
                                for office in offices:
                                    if (course.course_type == office.office_type):
                                        result.append((group.name, course.name, course.course_type, teacher.name, office.name,group_course[2]))
    return result

# Example usage:
if __name__ == "__main__":
    json_file = "file_1.json"
    teachers, courses, groups, offices = load_data_from_json(json_file)
    tuples_list = create_list_of_tuples(teachers, courses, groups, offices)

    for tuples in tuples_list:
        print(tuples)